
import random
from urllib.parse import quote
import flet as ft


def shift_letter(char, shift):
    if "a" <= char <= "z":
        return chr((ord(char) - ord("a") + shift) % 26 + ord("a"))
    if "A" <= char <= "Z":
        return chr((ord(char) - ord("A") + shift) % 26 + ord("A"))
    return char


def encode_message(message, key):
    shift = (key - 1) % 26
    result = []

    for char in message:
        if char == " ":
            result.append("dc")
        else:
            shifted = shift_letter(char, shift)
            result.append("dd" if shifted == "d" else shifted)

    return "".join(result)


def decode_message(message, key):
    shift = (key - 1) % 26
    result = []
    i = 0

    while i < len(message):
        char = message[i]

        if char == "d":
            if i + 1 >= len(message):
                raise ValueError("The code ends with an incomplete marker.")

            next_char = message[i + 1]

            if next_char == "c":
                result.append(" ")
                i += 2
                continue

            if next_char == "d":
                result.append(shift_letter("d", -shift))
                i += 2
                continue

            raise ValueError("Invalid code. Check the message.")

        result.append(shift_letter(char, -shift))
        i += 1

    return "".join(result)


def main(page: ft.Page):
    page.title = "Secret Code 999"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = "#101323"
    page.padding = 20
    page.scroll = ft.ScrollMode.AUTO

    key_input = ft.TextField(
        label="Secret number (1–999)",
        value="57",
        keyboard_type=ft.KeyboardType.NUMBER,
        border_radius=12,
        expand=True,
    )

    message_input = ft.TextField(
        label="Your message",
        hint_text="Type a message to encode or decode...",
        multiline=True,
        min_lines=4,
        max_lines=7,
        border_radius=12,
    )

    result_output = ft.TextField(
        label="Your result",
        hint_text="Your coded or decoded message appears here",
        multiline=True,
        min_lines=4,
        max_lines=7,
        read_only=True,
        border_radius=12,
    )

    status = ft.Text(
        "Your secret messages start here.",
        color="#B8C4E8",
        text_align=ft.TextAlign.CENTER,
    )

    def get_key():
        try:
            key = int(key_input.value)
            if 1 <= key <= 999:
                return key
        except (ValueError, TypeError):
            pass

        status.value = "Enter a whole number from 1 to 999."
        page.update()
        return None

    def encode_click(e):
        key = get_key()
        if key is None:
            return

        result_output.value = encode_message(
            message_input.value or "", key
        )
        status.value = f"Encoded successfully with key {key}."
        page.update()

    def decode_click(e):
        key = get_key()
        if key is None:
            return

        try:
            result_output.value = decode_message(
                message_input.value or "", key
            )
            status.value = f"Decoded successfully with key {key}."
        except ValueError as error:
            result_output.value = ""
            status.value = str(error)

        page.update()

    def random_click(e):
        key_input.value = str(random.randint(1, 999))
        status.value = "A new random key is ready!"
        page.update()

    async def copy_click(e):
        if not result_output.value:
            status.value = "Make a result first, then copy it."
            page.update()
            return

        try:
            await ft.Clipboard().set(result_output.value)
            status.value = "Copied to clipboard!"
        except Exception:
            status.value = "Select the result and copy with Ctrl+C."
        page.update()

    async def share_click(e):
        if not result_output.value:
            status.value = "Make a result first, then share it."
            page.update()
            return

        share_text = (
            f"Secret Code 999\n"
            f"Key: {key_input.value}\n"
            f"Message: {result_output.value}"
        )
        url = "https://wa.me/?text=" + quote(share_text)

        try:
            await page.launch_url(url)
            status.value = "Opening WhatsApp to share your message."
        except Exception:
            status.value = (
                "Sharing could not open. Copy the result instead."
            )
        page.update()

    page.add(
        ft.Container(
            content=ft.Column(
                controls=[
                    ft.Container(
                        content=ft.Column(
                            controls=[
                                ft.Text("🔐", size=42),
                                ft.Text(
                                    "SECRET CODE 999",
                                    size=28,
                                    weight=ft.FontWeight.BOLD,
                                    color="#FFFFFF",
                                    text_align=ft.TextAlign.CENTER,
                                ),
                                ft.Text(
                                    "Your words. Your key. Your secret.",
                                    size=14,
                                    color="#B8C4E8",
                                    text_align=ft.TextAlign.CENTER,
                                ),
                            ],
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            spacing=8,
                        ),
                        padding=20,
                        bgcolor="#242B48",
                        border_radius=20,
                    ),
                    ft.Text(
                        "1. CHOOSE YOUR KEY",
                        weight=ft.FontWeight.BOLD,
                        color="#A9B8FF",
                    ),
                    ft.Row(
                        controls=[
                            key_input,
                            ft.IconButton(
                                icon=ft.Icons.CASINO,
                                icon_color="#A9B8FF",
                                tooltip="Choose a random key",
                                on_click=random_click,
                            ),
                        ],
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    ft.Text(
                        "2. ENTER YOUR MESSAGE",
                        weight=ft.FontWeight.BOLD,
                        color="#A9B8FF",
                    ),
                    message_input,
                    ft.Row(
                        controls=[
                            ft.Button(
                                content="Encode",
                                icon=ft.Icons.LOCK,
                                on_click=encode_click,
                            ),
                            ft.Button(
                                content="Decode",
                                icon=ft.Icons.LOCK_OPEN,
                                on_click=decode_click,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        wrap=True,
                    ),
                    ft.Text(
                        "3. YOUR RESULT",
                        weight=ft.FontWeight.BOLD,
                        color="#A9B8FF",
                    ),
                    result_output,
                    ft.Row(
                        controls=[
                            ft.OutlinedButton(
                                "Copy",
                                icon=ft.Icons.CONTENT_COPY,
                                on_click=copy_click,
                            ),
                            ft.OutlinedButton(
                                "Share",
                                icon=ft.Icons.SHARE,
                                on_click=share_click,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                        wrap=True,
                    ),
                    status,
                    ft.Divider(color="#343B59"),
                    ft.Text(
                        "A fun secret code, not secure encryption. "
                        "Share your key only with people you trust.",
                        size=12,
                        color="#9CA7C7",
                        text_align=ft.TextAlign.CENTER,
                    ),
                ],
                spacing=16,
                horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
            ),
            width=600,
            padding=20,
            border_radius=24,
            bgcolor="#191E33",
        )
    )


if __name__ == "__main__":
    ft.run(main)
